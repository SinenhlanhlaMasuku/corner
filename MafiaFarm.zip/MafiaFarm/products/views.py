from django.shortcuts import render,redirect
from django.http.response import JsonResponse
from .models import Product


def index(request):
    products = Product.objects.all()
    return render(request, 'index.html', {'products': products})


def will_view(request):
    return render(request, 'WIL Assessement.html')


def checkout(request):
    return render(request, 'checkout.html')


def tester(request):
    if request.method == 'POST':
        myid = request.POST.get('myid')
        return JsonResponse({'status': 'my ID is ' + str(myid)})
    return redirect('/')
