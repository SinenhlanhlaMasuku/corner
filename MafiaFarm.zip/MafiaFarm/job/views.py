from django.shortcuts import render, redirect, get_object_or_404
from .models import Job
from django.contrib import messages
from .forms import JobApplicationForm
from .models import JobApplication


def submit_application(request):
    if request.method == 'POST':
        form = JobApplicationForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Application Submitted")
            return redirect('index')
    else:
        form = JobApplicationForm()

    return render(request, 'application_form/form.html', {'form': form})


def job_application(request):

    return render(request, 'application_form/form.html', {})


def jobs_list(request):
    jobs = Job.objects.all()
    return render(request, 'jobs/jobs_list.html', {'jobs': jobs})


def job_detail(request, job_id):
    job = get_object_or_404(Job, id=job_id)
    return render(request, 'jobs/job_detail.html', {'job': job})


def apply_job(request, job_id):
    # Handle the job application submission logic here
    return render(request, 'application_success.html')
