from django.urls import path
from . import views

urlpatterns = [
    path('submit_application', views.submit_application, name='submit_application'),
    path('job_application', views.job_application, name='job_application'),
    path('jobs/', views.jobs_list, name='jobs_list'),
    path('job/<int:job_id>/', views.job_detail, name='job_detail'),
    path('job/<int:job_id>/apply/', views.apply_job, name='apply_job'),
]
