from django.urls import path
from products import views


urlpatterns = [
    path('', views.index, name='index'),
    path('checkout', views.checkout, name='checkout'),
    path('tester', views.tester, name='tester'),
    path('will', views.will_view, name='will')
]
