from django.shortcuts import render, redirect, get_object_or_404
from .models import Job
from django.contrib import messages
from .forms import JobApplicationForm
from .models import JobApplication, Job


def submit_application(request, job_id):
    job = get_object_or_404(Job, id=job_id)

    if request.method == "POST":
        form = JobApplicationForm(request.POST, request.FILES)
        if form.is_valid():
            application = form.save(commit=False)
            application.job = job
            application.resume = request.FILES['resume']
            application.save()
            messages.success(request, "Application Submitted")
            return redirect('jobs_list')
    else:
        form = JobApplicationForm()

    return render(request, 'application_form/form.html', {'form': form, 'job_id': job_id})


def job_application(request):

    return render(request, 'application_form/form.html', {})


def jobs_list(request):
    jobs = Job.objects.all()
    return render(request, 'jobs/jobs_list.html', {'jobs': jobs})


def job_detail(request, job_id):
    job = get_object_or_404(Job, id=job_id)
    return render(request, 'jobs/job_detail.html', {
        'job': job,
        'job_id': job_id,
    })


def apply_job(request, job_id):
    # Handle the job application submission logic here
    return render(request, 'application_form/form.html', {
        'job_id': job_id,
    })
